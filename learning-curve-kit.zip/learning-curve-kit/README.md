# The Learning Curve: starter kit

Everything Claude Code needs to build thelearningcurve.net and run its twice-daily drafting.

## Setup, in order

1. Create an empty GitHub repo (e.g. `poetreefalling/thelearningcurve`) and unzip this kit into it.
2. Open it in Claude Code and say: "Read BUILD_BRIEF.md and build the site. Use
   poetreefalling/storybriefs as the reference." It opens a PR; review the preview and merge.
3. Cloudflare Pages: connect the repo, build command `npm run build`, output `dist`, add the
   custom domain thelearningcurve.net. Create a deploy hook and save it as the GitHub secret
   `CF_DEPLOY_HOOK`.
4. Save your two chosen style images as `brand/documentary-reference.webp` and
   `brand/risograph-reference.webp`.
5. Create a scheduled Claude Code task on the repo, twice a day (around 09:00 and 21:00
   Sydney), with the prompt: "Run the twice-daily article routine in CLAUDE.md." Connect the
   Ubersuggest and Artlist connectors to it.
6. Before reviews can run: test each platform and fill in `docs/testing/<platform>.md` from
   the template. Until then the routine skips review rows.
7. Apply to the PartnerStack programs; update `docs/affiliates.md` and `affiliateUrl` in
   `src/data/platforms.json` as approvals come in.

## What's in here

| File | Purpose |
|---|---|
| `BUILD_BRIEF.md` | One-off brief: design system, pages, components, schema, scheduled publishing |
| `CLAUDE.md` | Standing instructions, including the twice-daily routine |
| `docs/editorial.md` | Voice, article shapes, citation rules, review method, image prompts |
| `docs/backlog.md` | 12 flagships and a 40-article queue |
| `docs/affiliates.md` | Program terms, status and rules |
| `docs/testing/_template.md` | Your platform testing notes |
| `src/data/platforms.json` | The four platforms, affiliate links empty |
| `brand/README.md` | The image references to add |
