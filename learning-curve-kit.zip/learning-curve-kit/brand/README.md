# Brand assets

| File | What it is | Who supplies it |
|---|---|---|
| `documentary-reference.webp` | Style reference for documentary heroes: candid, window-lit, 35mm grain, faces soft or turned away | Jim: save the documentary test image he liked |
| `risograph-reference.webp` | Style reference for risograph heroes: navy and ochre on off-white, grain, misregistration | Jim: save the risograph test image he liked |
| `originals/` | Full-size originals of every generated hero, named `<slug>.png` | The routine |
| `screenshots/<platform>/` | Jim's own screenshots from testing | Jim |

The routine won't generate images until both reference files exist; without them it stops and
reports.
